import { useSelector, useDispatch } from "react-redux";
import { addTodo, editTodo, deleteTodo, toggleCompleted } from "./store/todo";
import "./CSS/myStyles.css"


function App() {
  const todos = useSelector(state => state.todo.data);
  const dispatch = useDispatch();

  // create function to handle when a new item is added , and return input field to default after being submited 
  const handleAddTodo = (e) => {
    e.preventDefault();
    const input = e.target.elements[0];
    if (!input.value.trim()) {
      return;
    }
    dispatch(addTodo(input.value));
    input.value = "";
  };

  // create function to handle when an item is edited
  const handleEditTodo = (id, content) => {
    const newContent = prompt("Edit todo:", content);
    if (newContent !== null) {
      dispatch(editTodo({ id, content: newContent }));
    }
  };

  // create function to delete a task item 
  const handleDeleteTodo = (id) => {
    if (window.confirm("Delete this todo?")) {
      dispatch(deleteTodo(id));
    }
  };

  // create a fucntion to mark a item as complete 
  const handleToggleCompleted = (id) => {
    dispatch(toggleCompleted(id));
  };


  return (
    <div id="myTodoPage">
      <h1>My To-do List</h1>

      {/* // a form to add new tasks to the list, calling handleAddToDo when submitted */}
      <form id="newTaskForm" onSubmit={handleAddTodo}>
        <label>Add a new task: </label>
        <input id="inputNewTask" placeholder="Add task here" />
        <button id="submitNewTask" type="submit">Add</button>
      </form>

      {/* // unordered list that maps all of the tasks in the state and adds each as an li */}
      <ul className="taskList">
        <h3>Current tasks:</h3>
        {Object.entries(todos).map(([id, todo]) => (
          <li key={id}>
            {/* // span that adds a strike through the task item with some inline CSS when the done button is clicked  */}
            <span
              style={{ textDecoration: todo.completed ? "line-through" : "none" }}
              onClick={() => handleToggleCompleted(id)}
            >
              {todo.content}
            </span>
              <div className="buttonSection">

                {/* // the required buttons all calling the relevant functions when clicked  */}
                <button className="taskButtons" onClick={() => handleEditTodo(id, todo.content)}>Edit</button>
                <button className="taskButtons" onClick={() => handleDeleteTodo(id)}>Delete</button>
                <button className="taskButtons" onClick={() => handleToggleCompleted(id)}>Done</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;


/* References:

- Pieter and his lecture - an invaluable resource with endless patience! he explains really well.

- I needed to do a fair bit of reading into redux to understand it, These linkes were helpful:
  - https://redux.js.org/tutorials/fundamentals/part-5-ui-react  
  - https://blog.logrocket.com/understanding-redux-tutorial-examples/
  - https://medium.com/swlh/few-ways-to-update-a-state-array-in-redux-reducer-f2621ae8061
*/