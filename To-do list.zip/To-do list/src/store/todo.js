// import createslice
import { createSlice } from "@reduxjs/toolkit";

// variable for initial state
const initialTodoState = {
  nextId: 3,
  data: {
    1: { content: "Task 1", completed: false },
    2: { content: "Task 2", completed: false }
  }
};

// create slice for all to do actions
const todoSlice = createSlice({

  name: "todo",

  initialState: initialTodoState,

    // create reducers for the slice
  reducers: {

    // create reducer for adding a to do item , that will take user input as the payload for content and increase the next id by 1
    addTodo: (state, action) => {
      const id = state.nextId++;
      state.data[id] = { content: action.payload, completed: false };
    },

    // create reducer to edit the content of a task item 
    editTodo: (state, action) => {
      const { id, content } = action.payload;
      state.data[id].content = content;
    },

      // create a reducer to delete a task item 
    deleteTodo: (state, action) => {
      delete state.data[action.payload];
    },

    // create a resucer to delete a task item 
    toggleCompleted: (state, action) => {
      const id = action.payload;
      state.data[id].completed = !state.data[id].completed;
    }


  
 }

});


// export all of the reducers 
export const { addTodo, editTodo, deleteTodo, toggleCompleted } = todoSlice.actions;

export default todoSlice.reducer;


